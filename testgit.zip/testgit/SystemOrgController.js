﻿/*
 * COPYRIGHT. ShenZhen JiMi Technology Co., Ltd. 2017.
 * ALL RIGHTS RESERVED.
 *
 * No part of this publication may be reproduced, stored in a retrieval system, or transmitted,
 * on any form or by any means, electronic, mechanical, photocopying, recording, 
 * or otherwise, without the prior written permission of ShenZhen JiMi Network Technology Co., Ltd.
 *
 * Amendment History:
 * 
 * Date                   By              Description
 * -------------------    -----------     -------------------------------------------
 * 2017年10月16日    wanghe         Create the class
 * http://www.jimilab.com/
 */

package com.jimi.api.system.controller.reqmap;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jimi.api.common.Globals;
import com.jimi.framework.base.APIContent;
import com.jimi.framework.base.APIPageContent;
import com.jimi.framework.base.dto.PageModel;
import com.jimi.upms.system.enums.system.SUserTypeEnum;
import com.jimi.upms.system.model.SystemOrgInfo;
import com.jimi.upms.system.model.SystemUserInfo;
import com.jimi.upms.system.service.SystemOrgInfoService;

/**
 * @FileName SystemOrgController.java
 * @Description: 
 *
 * @Date 2017年10月16日 下午4:28:09
 * @author wanghe
 * @version 1.0
 */
@Controller
@RequestMapping("/org")
public class SystemOrgController {

	private static final Logger logger = LoggerFactory.getLogger(SystemOrgController.class);

	@Autowired
	private SystemOrgInfoService systemOrgInfoService;


	/**
	 * @Title: selectOrgPage 
	 * @Description:	查询本人机构下的所有机构 根据关键字过滤
	 * @param request
	 * @param page
	 * @param entity
	 * @return 
	 * @author wanghe
	 * @date 2017年10月25日 10:38:30
	 */
	@RequestMapping("/selectOrgPage")
	@ResponseBody
	public APIPageContent selectOrgPage(HttpServletRequest request, PageModel<SystemOrgInfo> page, SystemOrgInfo entity){
		try {
			SystemUserInfo user = (SystemUserInfo) request.getSession().getAttribute(Globals.LOGIN_USER);
			entity.setId(user.getId());
			page.setObj(entity);
			page = systemOrgInfoService.selectMyOrg(page,(SUserTypeEnum.SUPER.getValue()+"").equals(user.getUserType()));
			APIPageContent vo = new APIPageContent(0,"操作成功",page.getResult(), page.getTotalCount()); 
			vo.setPage(page.getPage());
			vo.setPageCount(page.getPageCount());
			return vo;
		} catch (Exception e){
			logger.error("查询机构失败", e);
		}
		return new APIPageContent(500, "查询机构失败", null, 0L);
	}

	/**
	 * @Title: findOrgTree 
	 * @Description:			查询出来本人所管理的机构树
	 * @param request
	 * @param response
	 * @return 
	 * @author wanghe
	 * @date 2017年10月16日 下午4:29:46
	 */
	@RequestMapping(value = "/findOrgTree")
	@ResponseBody
	public SystemOrgInfo[] findOrgTree(HttpServletRequest request, HttpServletResponse response){
		//区分一下是否是管理员
		SystemUserInfo user =(SystemUserInfo) request.getSession().getAttribute(Globals.LOGIN_USER);
		List<SystemOrgInfo> list ;
		if((SUserTypeEnum.SUPER.getValue()+"").equals(user.getUserType())){
			list=systemOrgInfoService.selectOrgTree(0);
		}else{
			//这里要改成根据登陆用户的机构来查询 wanghe2017
			list=systemOrgInfoService.selectOrgTree(user.getOrgId());
		}
		return (SystemOrgInfo[])list.toArray(new SystemOrgInfo[list.size()]);
	}

	@RequestMapping(value = "/orgPage")
	public String orgPage() {
		return "system/org/orgPage";
	}
	
	@RequestMapping(value = "/toAddOrg")
	public String toAddOrg() {
		return "system/org/addOrg";
	}

	@RequestMapping(value = "/addOrg" , method =  RequestMethod.POST)
	@ResponseBody
	public APIContent addOrg(HttpServletRequest request, SystemOrgInfo org){
		APIContent vo = new APIContent();
		try {
			if(org != null){
				//判断是否存在上级机构
				if(org.getOrgSupId() == null ){
					//管理员
					SystemUserInfo user =(SystemUserInfo) request.getSession().getAttribute(Globals.LOGIN_USER);
					if((SUserTypeEnum.SUPER.getValue()+"").equals(user.getUserType())){
						org.setOrgSupId(0);
					}else{
						vo.setCode(500);
						vo.setMsg("请选择上级机构");
						return vo;
					}
				}
				String tempOrgCode;
				//有上级机构
				if(org.getOrgSupId() != 0){
					SystemOrgInfo pOrg=systemOrgInfoService.selectOrg(org.getOrgSupId());
					tempOrgCode=pOrg.getOrgCode();
					Integer tempNum=systemOrgInfoService.selectMaxOrgCode(tempOrgCode);
					tempNum=tempNum==null?1:tempNum+1;
					org.setOrgCode(tempOrgCode+com.jimi.framework.utils.StringUtil.fillBeforeZero(tempNum+"", 4));
					org.setTopOrgId(pOrg.getTopOrgId());
				}

				if(org.getOrgName() != null && !"".equals(org.getOrgName())){
					if(systemOrgInfoService.existsByName(org.getOrgName(), org.getId(), org.getOrgSupId())){
						vo.setCode(500);
						vo.setMsg("该名称已存在");
					}else{
						org.setCreateTime(new Date());
						org.setCreateUserId( (Integer)request.getSession().getAttribute(Globals.USER_ID));
						org.setUpdateTime(org.getCreateTime());
						org.setUpdateUserId( (Integer)request.getSession().getAttribute(Globals.USER_ID));
						systemOrgInfoService.insertOrg(org);
						//主要是针对顶层机构
						if(org.getOrgSupId() == 0){
							org.setTopOrgId(org.getId());
							tempOrgCode=com.jimi.framework.utils.StringUtil.fillBeforeZero(org.getId()+"", 10);
							org.setOrgCode(tempOrgCode);
							systemOrgInfoService.updateOrg(org);
						}
						vo.setCode(0);
						vo.setMsg("操作成功");
					}
				}else{
					vo.setCode(500);
					vo.setMsg("名称一定要必填");
				}
			}
		} catch (Exception e){
			e.printStackTrace();
			vo.setCode(500);
			vo.setMsg("添加机构信息失败");
			logger.error("添加机构信息失败", e);
		}
		return vo;
	}


	@RequestMapping("/editOrg")
	@ResponseBody
	public APIContent editOrg(HttpServletRequest request, SystemOrgInfo org){
		APIContent vo = new APIContent();
		try {
			//判断是否存在上级机构
			if(org.getOrgSupId() == null ){
				//管理员
				SystemUserInfo user =(SystemUserInfo) request.getSession().getAttribute(Globals.LOGIN_USER);
				if((SUserTypeEnum.SUPER.getValue()+"").equals(user.getUserType())){
					org.setOrgSupId(0);
				}else{
					vo.setCode(500);
					vo.setMsg("请选择上级机构");
					return vo;
				}
			}

			SystemOrgInfo oldOrg=systemOrgInfoService.selectOrg(org.getId());
			//如果上级机构发生变化
			if(oldOrg.getOrgSupId() != org.getOrgSupId()){
				//新的orgCode
				String tempOrgCode;
				//顶层机构时候
				if(org.getOrgSupId() == 0){
					tempOrgCode=com.jimi.framework.utils.StringUtil.fillBeforeZero(org.getId()+"", 10);
					org.setOrgCode(tempOrgCode);
					org.setTopOrgId(org.getId());
				}else{
					//准备迁移过的上级机构信息
					SystemOrgInfo pOrg=systemOrgInfoService.selectOrg(org.getOrgSupId());
					tempOrgCode=pOrg.getOrgCode();
					Integer tempNum=systemOrgInfoService.selectMaxOrgCode(tempOrgCode);
					tempNum=tempNum==null?1:tempNum+1;
					System.out.println("本机构下原本最大的机构序号为"+tempNum);
					org.setOrgCode(tempOrgCode+com.jimi.framework.utils.StringUtil.fillBeforeZero(tempNum+"", 4));
					org.setTopOrgId(pOrg.getTopOrgId());
				}
			}

			//新机构下名称是否重复
			if(org.getOrgName() != null && !"".equals(org.getOrgName())){
				if(systemOrgInfoService.existsByName(org.getOrgName(), org.getId(), org.getOrgSupId())){
					vo.setCode(500);
					vo.setMsg("机构名称【"+org.getOrgName()+"】已存在");
				}else{
					org.setUpdateTime(new Date());
					org.setUpdateUserId( (Integer)request.getSession().getAttribute(Globals.USER_ID));
					systemOrgInfoService.updateOrg(org);
					if(oldOrg.getOrgSupId() != org.getOrgSupId()){
						//变更了上级机构 不止是更新本身的orgCode 还会同步更新其子菜单的orgCode
						systemOrgInfoService.updateOrgCode(oldOrg.getOrgCode(), org.getOrgCode());
						//变更了上级机构 不止是更新本身的topOrgId 还会同步更新其子菜单的topOrgId
						systemOrgInfoService.updateTopOrgId(org.getTopOrgId()+"", org.getOrgCode());
					}
					vo.setCode(0);
					vo.setMsg("操作成功");
				}
			}else{
				vo.setCode(500);
				vo.setMsg("机构名称不能为空");
			}
		} catch (Exception e){
			vo.setCode(500);
			vo.setMsg("修改机构信息失败");
			logger.error("修改机构信息失败", e);
		}
		return vo;
	}

	@RequestMapping("/deleteOrg")
	@ResponseBody
	public APIContent deleteOrg(HttpServletRequest request, Integer id){
		APIContent vo = new APIContent();
		try {
			//删除机构之前，需要判断
			Integer numA=systemOrgInfoService.selectCountOrg(id);
			Integer numB=systemOrgInfoService.selectCountUser(id);
			if(numA+numB > 0){
				vo.setCode(500);
				vo.setMsg("该机构存在下属机构数【"+numA+"】,下属用户数【"+numB+"】,无法删除！");
			}else{
				systemOrgInfoService.deleteOrg(id);
				vo.setCode(0);
				vo.setMsg("操作成功");	
			}
		} catch (Exception e){;
		vo.setCode(500);
		vo.setMsg("删除机构失败");
		logger.error("删除机构失败", e);
		}
		return vo;
	}

}