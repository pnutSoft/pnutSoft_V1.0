var form;
var $form;
var $;
layui.config({
	base : "js/"
}).use(['form','layer'],function(){
	form = layui.form;
	var layer = parent.layer === undefined ? layui.layer : parent.layer;
		$ = layui.jquery,
		$form = $('form'),		
		form.render('radio');//重新渲染单选按钮
	 			
		//初始化树
		initOrgTree("editTree","orgSupId","orgSupName",null,null);
   		
   	    //增加
   	    form.on('submit(addOrg)', function(data){
   	 		var params = {
	 			'orgName': $("#orgName").val(),
	 			'orgTel': $.trim($("#orgTel").val()),
	 			'orgSupId': $("#orgSupId").val(),
	 			'orgSn' : $.trim($("#orgSn").val())
   		 	}
	   	 	var ind = layer.msg('提交中，请稍候',{icon: 16,time:false,shade:0.6});	        
	 		$.ajax({
				url :_ctx + "/org/addOrg",
				type : "POST",
				dataType : "json",
				data : params,
				success : function(data) {
					var index = parent.layer.getFrameIndex(window.name); 
					if (data.code == '0'){
						layer.close(index);
						parent.location.reload(); 							
					}					
					layer.close(ind);
					layer.msg(data.msg);					
				}
			});
 	  });
})
$(function(){
	initAuthFuncBtnByTag(); //初始化按钮权限
});