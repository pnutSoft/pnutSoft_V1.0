var tempData;
layui.config({
	base: 'js/'
}).use(["form","jquery","element","table",'laypage', "layer"], function() {
	var form = layui.form;
	var $ = layui.$;
	var laytpl = layui.laytpl;
	layer = parent.layer === undefined ? layui.layer : parent.layer,
	$ = layui.jquery,
	laypage = layui.laypage, 
	element = layui.element,
	table = layui.table;

	table.render({
		elem:"#orgReload",
		height:"full-90",
		cols: [[ //标题栏
		         {field: 'orgName', title: '公司/部门名称', width: 240,sort: true}
		         ,{field: 'orgSupName', title: '上级公司/部门名称', width: 240,sort: true}
		         ,{field: 'createTime', title: '创建时间', width: 180,sort: true}
		         ,{field: 'createUserName', title: '创建人', width: 80,sort: true}
		         ,{field: 'updateTime', title: '修改时间', width:180 ,sort: true}
		         ,{field: 'updateUserName', title: '修改人', width:80 ,sort: true}
		         ,{field: 'orgTel', title: '联系方式', width: 200}
		         ,{field: 'creation', title: '操作', width: 140,toolbar:'#barButton',fixed:"right"}
		         ]]
		,id : 'orgReload'
		,page : true,
		even : true, // 表格隔行背景
		loading: true,
		url : _ctx + '/org/selectOrgPage',
		method : 'post',
		limits : comm.rowList,
		limit : comm.rowNumbers, // 每页默认显示的数量
		request : {
			pageName : 'page', // 页码的参数名称，默认：page
			limitName : 'limit' // 每页数据量的参数名，默认：limit
		},
		response : {
			statusName : 'code' // 数据状态的字段名称，默认：code
				,statusCode : 0 // 成功的状态码，默认：0
				,msgName : 'msg' // 状态信息的字段名称，默认：msg
					,countName : 'totalCount' // 数据总数的字段名称，默认：count
						,dataName : 'data' // 数据列表的字段名称，默认：data
		},
		done : function(res, curr, count) {
			// 如果是异步请求数据方式，res即为你接口返回的信息。
			// 如果是直接赋值的方式，res即为：{data: [], count: 99}
			// data为当前页数据、count为数据总长度
			// 表格加载成功后的回调
			initAuthFuncBtnByTag(); //初始化按钮权限
			var rows = res.data;
			for (var i = 0; i < rows.length; i++) {
				var id = rows[i].id;
				var row = rows[i];
			};
		}
	});

	// 监听工具条
	table.on('tool(orgFilter)', function(obj) {
		tempData = obj.data;
		if (obj.event === 'editOrg') {
			var index = layui.layer.open({
				title : "组织机构架构图",
				type : 2,
				content : _ctx+"/org/orgPage",
				success : function(layero, index){
					layui.layer.full(index);
				}
			})
		} else if (obj.event === 'deleteOrg') {
			layer.confirm('确定删除【'+obj.data.orgName+'】？', {
				icon : 3,
				title : '提示信息'
			}, function() {
				var params = {
						'id' : obj.data.id
				}
				var index = layer.msg('删除中，请稍候', {
					icon : 16,
					time : false,
					shade : 0.6
				});
				$.ajax({
					url : _ctx + "/org/deleteOrg",
					type : "POST",
					dataType : "json",
					data : params,
					success : function(data) {
						if (data.code == '0'){					
							layer.close(index);
							//清空编辑框
							$("input").val("");
						}		
						layer.msg(data.msg);
						renderData();
					}
				});
			});
		}
	});

	//定义按钮事件
	$('.layui-btn').on('click', function(){
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';
	});

	// 渲染 toolbar
	var $ = layui.$, active = {
			searchData : function() {
				renderData();
			},
			clearSearch : function() {
				$('#searchId').val("");
			},
			toOrgTree:function(){
				tempData=null;
				var index = layui.layer.open({
					title : "组织机构架构图",
					type : 2,
					content : _ctx+"/org/orgPage",
					area:["800px","600px"],
					success : function(layero, index){
						layui.layer.full(index);
					}
				})
			}
	};
	function renderData(){
		// 表格重载
		var whereVal = {
				'orgName' : $('#searchId').val()
		};
		table.reload('orgReload', {
			where : whereVal
		});
	}

	//添加了回车调用查询
	$("#searchId").on('keydown', function(e){
		if(e.keyCode == 13){
			renderData();
		}
	})
});

$(function(){
	initAuthFuncBtnByTag(); //初始化按钮权限
});