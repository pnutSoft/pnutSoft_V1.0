var form;
var $form;
var $;
layui.config({
	base : "js/"
}).use(['jquery','form','layer','element'],function(){
	form = layui.form;
	var layer = parent.layer === undefined ? layui.layer : parent.layer;
	$ = layui.jquery,
	$form = $('form'),		
	form.render('radio');//重新渲染单选按钮

	
	// 填充修改数据
	var pData=parent.tempData;
	//当前左侧树节点
	var tempSelectNode=null;
	var ret = new Array(); 
	initOrg();
	
	function initOrg(){
		//初始化左侧树
		initOrgTree("addTree","id","orgName",pData,onClickLeftTree);
		
		//初始化左侧所选节点的子集
		if(pData !=null){
			setOrgInfo(pData);
		}
		
		//初始化右侧树
		var pNode={};
		if(pData !=null){
			pNode.id=pData.orgSupId;
		}
		initOrgTree("editTree","orgSupId","orgSupName",pNode,selectEditOrgTree);
	}

	/**
	 * 设置机构信息
	 */
	function initOrgFrom(selectNode){
		$("#id").val(selectNode.id);
		$("#orgSupId").val(selectNode.orgSupId);
		$("#orgSupName").val(selectNode.orgSupName);
		$("#orgCode").val(selectNode.orgCode);
		$("#topOrgId").val(selectNode.topOrgId);
		$("#orgName").val(selectNode.orgName);
		$("#orgTel").val(selectNode.orgTel);
		$("#orgSn").val(selectNode.orgSn);
	}

	//设置orgInfo
	function onClickLeftTree(treeId){
		var treeObj = $.fn.zTree.getZTreeObj(treeId);
		var selectNode = treeObj.getSelectedNodes()[0];
		setOrgInfo(selectNode);
		
		//点击左侧的时候 重新选中右侧的节点
		var treeObj2 = $.fn.zTree.getZTreeObj("editTree");
		if(selectNode.getParentNode()){
			var node =  treeObj2.getNodeByParam("id", selectNode.getParentNode().id, null);
			treeObj2.selectNode(node);
		}else{
			treeObj2.selectNode();
		}
	}
	
	function setOrgInfo(selectNode){
		if(selectNode){
			tempSelectNode=selectNode;
		}
		initOrgFrom(tempSelectNode);
		
		ret= new Array();
		ret.push(tempSelectNode.id);//当前节点的id
		getAllChildrenNodes(tempSelectNode);
	}

	//定义按钮事件
	$('.layui-btn').on('click', function(){
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';
	});
	
	// 渲染 toolbar
	var $ = layui.$, active = {
			closeWin : function() {
				parent.location.reload();
			},
			toAdd : function() {
				var index = layui.layer.open({
					title : "添加机构",
					type : 2,
					offset:'1%',
					area:["600px","600px"],
					content : _ctx+"/org/toAddOrg",
					success : function(layero, index) {
					}
				})
			}
	};
	
	form.on('submit(editOrg)', function(data){
		var params = {
				'id': $("#id").val(),
				'orgName': $("#orgName").val(),
				'orgTel': $.trim($("#orgTel").val()),
				'orgSupId': $("#orgSupId").val(),
				'orgSn' : $.trim($("#orgSn").val())
		}
		var ind = layer.msg('提交中，请稍候',{icon: 16,time:false,shade:0.6});	        
		$.ajax({
			url :_ctx + "/org/editOrg",
			type : "POST",
			dataType : "json",
			data : params,
			success : function(data) {
				var index = parent.layer.getFrameIndex(window.name); 
				if (data.code == '0'){
					layer.close(index);
					parent.location.reload();
				}					
				layer.close(ind);
				layer.msg(data.msg);					
			}
		});
	});
	
	$(".js-select-sales-btn").click(function() {
        var flag = $(this).find(".iconfont").hasClass("icon-xiala");
        orgrTreeToggle(flag);
    });
	
    //所说上级用户树切换显示
    function orgrTreeToggle(flag) {
        if (!flag) {
            $(".js-select-user-sales-tree-box").hide();
            $(".js-select-sales-btn").find(".iconfont").attr("class", "iconfont icon-xiala");
        } else {
            $(".js-select-user-sales-tree-box").show();
            $(".js-select-sales-btn").find(".iconfont").attr("class", "iconfont icon-shangla");
        }
    }
    
    /**
     * 重新选择父级节点时
     */
    function selectEditOrgTree(treeId){
    	//所选择的上级机构
    	var treeObj = $.fn.zTree.getZTreeObj(treeId);
		var selectNode = treeObj.getSelectedNodes()[0];
		if($.inArray(selectNode.id, ret) == -1){
			$("#orgSupId").val(selectNode.id);
			$("#orgSupName").val(selectNode.orgName);
		}else{
				$("#orgSupId").val(tempSelectNode.orgSupId);
				$("#orgSupName").val(tempSelectNode.orgSupName);
			layer.alert("不能选择子节点或本身节点做父级");
		}
    }
	
	//当前节点及子节点，不能选作父级
	//重新加载左侧所选节点子集
	function getAllChildrenNodes(treeNode){
	      if (treeNode.isParent) {
	        var childrenNodes = treeNode.children;
	        if (childrenNodes) {
	            for (var i = 0; i < childrenNodes.length; i++) {
	            	ret.push(childrenNodes[i].id);
	            	getAllChildrenNodes(childrenNodes[i]);
	            }
	        }
	    }
	}
})
$(function(){
	initAuthFuncBtnByTag(); //初始化按钮权限
});