/*
 * COPYRIGHT. ShenZhen JiMi Technology Co., Ltd. 2017.
 * ALL RIGHTS RESERVED.
 *
 * No part of this publication may be reproduced, stored in a retrieval system, or transmitted,
 * on any form or by any means, electronic, mechanical, photocopying, recording, 
 * or otherwise, without the prior written permission of ShenZhen JiMi Network Technology Co., Ltd.
 *
 * Amendment History:
 * 
 * Date                   By              Description
 * -------------------    -----------     -------------------------------------------
 * 2017年7月18日    HuangWeiMou         Create the class
 * http://www.jimilab.com/
*/

package com.jimi.framework.base;

/**
 * @FileName APIContentVo.java
 * @Description:
 *
 * @Date 2017年7月18日 下午4:38:13
 * @author HuangWeiMou
 * @version 1.0
 */
public class APIContent {

	private int code;

	private String msg;

	private Object data;
	
	
	public APIContent() {
		super();
	}

	public APIContent(int code) {
		super();
		this.code = code;
	}
	
	public APIContent(int code, String msg) {
		super();
		this.code = code;
		this.msg = msg;
	}

	public APIContent(int code, String msg, Object data) {
		super();
		this.code = code;
		this.msg = msg;
		this.data = data;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
