/*
 * COPYRIGHT. ShenZhen JiMi Technology Co., Ltd. 2017.
 * ALL RIGHTS RESERVED.
 *
 * No part of this publication may be reproduced, stored in a retrieval system, or transmitted,
 * on any form or by any means, electronic, mechanical, photocopying, recording, 
 * or otherwise, without the prior written permission of ShenZhen JiMi Network Technology Co., Ltd.
 *
 * Amendment History:
 * 
 * Date                   By              Description
 * -------------------    -----------     -------------------------------------------
 * 2017年9月7日    TangYuping         Create the class
 * http://www.jimilab.com/
*/

package com.jimi.framework.base;

/**
 * @FileName APIPageContent.java
 * @Description: 
 *
 * @Date 2017年9月7日 下午5:59:44
 * @author TangYuping
 * @version 1.0
 */
public class APIPageContent {

	private int code;

	private String msg;

	private Object data;
	
	private Long totalCount;
	
	private int pageCount; // 页数
	
	private int page; //跳转页
	
	
	public APIPageContent() {
		super();
	}

	public APIPageContent(int code) {
		super();
		this.code = code;
	}
	
	public APIPageContent(int code, String msg) {
		super();
		this.code = code;
		this.msg = msg;
	}

	public APIPageContent(int code, String msg, Object data) {
		super();
		this.code = code;
		this.msg = msg;
		this.data = data;
	}
	
	public APIPageContent(int code, String msg, Object data, Long totalCount) {
		super();
		this.code = code;
		this.msg = msg;
		this.data = data;
		this.totalCount = totalCount;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	
	
}
